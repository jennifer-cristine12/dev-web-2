var tabuada = require ("./multiplicacao.js")
var b =1
var a=2;
while (b<=10) {
    console.log(a,"x",b,"=",tabuada(a,b))
    b++
}